# Name: Teng Tze Hui & Ng Jace Xin
# Student ID: 2214209 & 2214593
# Class: DAAA/2B/01

import re

class Tokenization:
    def tokenize(exp):
        # Operators to be considered as separate tokens
        operators = ['+', '-', '*', '/', '**']

        tokens = []
        current_token = ''

        is_unary_minus = True # Flag to track unary minus

        try:

            for char in exp:

                # Skip whitespace characters
                if char.isspace():
                    continue
                
                # alnum returns "true" is the char is a letter or a number
                if char.isalnum() or char == '.':
                    current_token += char # char is appended into current_token variable
                    is_unary_minus = False  # Reset the unary_minus flag 
                
                elif char == '-' and is_unary_minus:
                    # Handle unary minus
                    current_token += char
                    is_unary_minus = False

                elif char in operators:
                    # Handle operators
                    if current_token:
                        tokens.append(current_token)
                        current_token = ''

                    if tokens and tokens[-1] == char:
                        # Combine consecutive asterisks
                        tokens[-1] = '**'
                    else:
                        tokens.append(char)

                    is_unary_minus = True  # Reset the unary_minus flag

                elif char == '(':
                    # Handle opening parenthesis
                    if current_token:
                        tokens.append(current_token)
                        current_token = ''

                    tokens.append(char)
                    is_unary_minus = True  # Reset the unary_minus flag

                elif char == ')':
                    # Handle closing parenthesis
                    if current_token:
                        tokens.append(current_token)
                        current_token = ''

                    tokens.append(char)

                else:
                    # Raise an error for invalid characters
                    raise ValueError(f"Invalid character: {char}")
                
            if current_token:
                tokens.append(current_token)

        except ValueError as e:
            print(f"\nError during tokenization: {e}")

        return tokens
                